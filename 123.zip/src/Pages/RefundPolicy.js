import React from 'react'
import BreadCrumb from '../Components/BreadCrumb';
import Meta from '../Components/Meta';
const RefundPloicy = () => {
  return (
    <>
         <Meta title={"Refund Ploicy"} />
      <BreadCrumb title="Refund Ploicy" />
      <section className='policy-wrapper py-5 home-wrapper-2'>
        <div className='container-xxl'>
           <div className='row'>
            <div className='col-12'>
              <div className='policy-wrapper py-5 home-wrapper-2'></div>
            </div>
           </div>
        </div>
      </section>  
    </>
  )
}

export default RefundPloicy
