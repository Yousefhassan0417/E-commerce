// export const services = [
//     {
//         Images:"Free Shipping",
//         title:"From all orders over $5",
//         tagline:"images/services.png",
//     },

//     {
//         title:"Daily surprise offers",
//         tagline:"Save upto 25% off",
//         image:"images/service-02.png",
//     },

//     {
//         title:"Daily surprise offers",
//         tagline:"Save upto 25% off",
//         image:"images/service-03.png",
//     },

//     {
//         title:"support 24/7",
//         tagline:"shop with an expert",
//         image:"images/service-04.png",
//     },

//     {
//         title:"Affordable Prices",
//         tagline:"Get Factory Default price",
//         image:"images/service-04.png",
//     },

//     {
//         title:"Secure Payments",
//         tagline:"100% protected Payment",
//         image:"images/service-04.png",
//     },
    
// ];

    
